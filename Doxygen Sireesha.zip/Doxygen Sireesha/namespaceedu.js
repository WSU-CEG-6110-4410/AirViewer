var namespaceedu =
[
    [ "wright", "namespaceedu_1_1wright.html", "namespaceedu_1_1wright" ]
];