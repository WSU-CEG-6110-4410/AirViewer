var namespaces_dup =
[
    [ "edu", "namespaceedu.html", "namespaceedu" ]
];