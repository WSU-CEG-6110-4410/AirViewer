var searchData=
[
  ['undo',['undo',['../classedu_1_1wright_1_1airviewer2_1_1_abstract_document_command_wrapper_a0dc2f00d47f32e216befde4f84e8e0fe.html#a0dc2f00d47f32e216befde4f84e8e0fe',1,'edu::wright::airviewer2::AbstractDocumentCommandWrapper']]],
  ['undoname',['undoName',['../classedu_1_1wright_1_1airviewer2_1_1_abstract_document_command_wrapper_1_1_abstract_document_command_a26fa05959551583b8ab953307e0eeae5.html#a26fa05959551583b8ab953307e0eeae5',1,'edu::wright::airviewer2::AbstractDocumentCommandWrapper::AbstractDocumentCommand']]]
];
