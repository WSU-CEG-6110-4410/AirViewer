var module_info_8java =
[
    [ "airviewer2", "module-info_8java.html#ae16dc8c8adb6a3c7ef07afde4e1174e0", null ],
    [ "base", "module-info_8java.html#afa15946bc7b850f464c864ad6bc363e4", null ],
    [ "cofoja", "module-info_8java.html#a4c06fa260553cca3681ab2c758332df8", null ],
    [ "fxml", "module-info_8java.html#a24bb561638234e2a699e8a544888f4a5", null ],
    [ "graphicsEmpty", "module-info_8java.html#a15db478d2cafbd7b05904753b0e091fb", null ],
    [ "junit", "module-info_8java.html#a59ab9e90db1dca57f2b5145d9e4e1544", null ],
    [ "pdfbox", "module-info_8java.html#a7dbb988b19b652682adbf4efb085a8ea", null ],
    [ "swing", "module-info_8java.html#a5fa6ba314ad9c8e50b5e0fabb9731465", null ]
];