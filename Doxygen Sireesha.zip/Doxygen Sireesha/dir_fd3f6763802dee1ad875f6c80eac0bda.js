var dir_fd3f6763802dee1ad875f6c80eac0bda =
[
    [ "edu", "dir_08b1a5388a6ca1211ec703e85dac0ff8.html", "dir_08b1a5388a6ca1211ec703e85dac0ff8" ],
    [ "module-info.java", "module-info_8java.html", "module-info_8java" ]
];