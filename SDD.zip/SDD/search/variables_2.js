var searchData=
[
  ['undoname',['undoName',['../classedu_1_1wright_1_1airviewer2_1_1_abstract_document_command_wrapper_1_1_abstract_document_command_a26fa05959551583b8ab953307e0eeae5.html#a26fa05959551583b8ab953307e0eeae5',1,'edu::wright::airviewer2::AbstractDocumentCommandWrapper::AbstractDocumentCommand']]]
];
