var searchData=
[
  ['owner',['owner',['../classedu_1_1wright_1_1airviewer2_1_1_abstract_document_command_wrapper_1_1_abstract_document_command_ab867f153ebb2c4cb4647948bfd529f3b.html#ab867f153ebb2c4cb4647948bfd529f3b',1,'edu::wright::airviewer2::AbstractDocumentCommandWrapper::AbstractDocumentCommand']]]
];
