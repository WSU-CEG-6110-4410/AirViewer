var searchData=
[
  ['initialize',['initialize',['../classedu_1_1wright_1_1airviewer2_1_1_a_i_r_viewer_controller_a625fa457c2996e27709942671eff7ded.html#a625fa457c2996e27709942671eff7ded',1,'edu::wright::airviewer2::AIRViewerController']]]
];
